/**
  ******************************************************************************
  * @file main.c 
  * @author RoboGame Sonny Team
  * @data 11/9
  * @version 1.11
  * @brief ������ ���赥�����Ի�е�� ���ȵ���testArm
  * @note: �����ļ� all
  ******************************************************************************
**/
#include "stm32f4xx.h"
#include "stepperMotor.h"
#include "motorContral.h"
#include "servoContral.h"
#include "leadscrew.h"
#include "helper.h"
#include "init.h"
#include "RobotArmMotion.h"
#include "rfid.h"


int main(void)
{
	preinit();
	//readBooks();
	init();
	//testArm();
	/*
	while(RecentBookNumber<5){
		Fetch(SortedBooks[RecentBookNumber][1]);
		Put(SortedBooks[RecentBookNumber][1],SortedBooks[RecentBookNumber][2]);
		RecentBookNumber++;
	}
	*/
	while(1){
		;
	}
}
