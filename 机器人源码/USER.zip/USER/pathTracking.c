/**
  ******************************************************************************
  * @file pathTracking.c 
  * @author RoboGame Sonny Team
  * @data 11/9
  * @version 1.1
  * @brief ��ȡ��ǰλ����Ϣ 
  *        λ�þ��� MAT_POSITION
  *        λ�ã���ǰ��������
  *        POSITON [0]��ת [1] [2] [4] [8] [16] [32]
  * @note: �����ļ� "pathTracking.h"
  ******************************************************************************
**/
/**
  ******************************************************************************
  * ѭ��������λ��˵����
  *                               ��ͷ
  *       
  *
  *
  *              |LINE1|   |LINE2|   |LINE3|   |LINE4|      
  * |LINE0|                                                 |LINE5|
  *              |LINE9|   |LINE8|   |LINE7|   |LINE6|      
  *
  *
  *
  *     
  *                               ��β
  ******************************************************************************
**/
/**
  *ѭ��˼·�� ֱ��ʱ������LINE1 �� LINE4 ��ֵ�ж��Ƿ�ƫ�뺽�ߣ���ƫ�룬ת��̶���ʱ�䣩������
  *         ����LINE4 && LINE1 (����)
  *         ת��ʱ����ѭ��ȷ��ת�����
**/
#include "pathTracking.h"

#define TURING_DELAY_MY //�ݶ����ת�䷽��

extern BOOLEAN TURNING = FALSE;
extern BOOLEAN TURN_RIGHT_SUCCESS = FALSE; //ת�������־������ΪTRUE�����ת��
extern BOOLEAN TURN_LEFT_SUCCESS = FALSE;
/*λ�þ����е�ǰλ��*/
extern u32 POSITON = UNCHANGED;
/*λ�þ���*/
extern u8 MAT_POSITION[12] = {0};
/*�޸�λ�þ���*/
void setCurPositionMat_And_Position(void){
    MAT_POSITION[0] = LINE1_1;
    MAT_POSITION[1] = LINE1_2; 
    MAT_POSITION[2] = LINE1_3;
    MAT_POSITION[3] = LINE1_4;
    MAT_POSITION[4] = LINE2_1;
    MAT_POSITION[5] = LINE2_2;
    MAT_POSITION[6] = LINE2_3;
    MAT_POSITION[7] = LINE2_4;
    MAT_POSITION[8] = LINE3_1;
    MAT_POSITION[9] = LINE3_2;
    // MAT_POSITION[10] = LINE3_3;
    // MAT_POSITION[11] = LINE3_4;

    if(direction == FRONT){
        if(MAT_POSITION[0]){
            POSITON = L_TURN;
        }else if(MAT_POSITION[5]){
            POSITON = R_TURN;
        }else if(MAT_POSITION[1]){
            POSITON = L_RANGE_2;
        }else if(MAT_POSITION[4]){
            POSITON = R_RANGE_2;
        }else if(MAT_POSITION[2]){
            POSITON = L_RANGE_1;
        }else if(MAT_POSITION[3]){
            POSITON = R_RANGE_1;
        }else{
            POSITON = UNCHANGED;
        }
    }else{
        if(MAT_POSITION[0]){
            POSITON = R_TURN;
        }else if(MAT_POSITION[5]){
            POSITON = L_TURN;
        }else if(MAT_POSITION[9]){
            POSITON = R_RANGE_2;
        }else if(MAT_POSITION[6]){
            POSITON = L_RANGE_2;
        }else if(MAT_POSITION[8]){
            POSITON = R_RANGE_1;
        }else if(MAT_POSITION[7]){
            POSITON = L_RANGE_1;
        }else{
            POSITON = UNCHANGED;
        }
    }
}
/*����Ƿ�ת��ɹ�*/
void testHadTuringSuccess(void){
    MAT_POSITION[0] = LINE1_1;
    MAT_POSITION[1] = LINE1_2; 
    MAT_POSITION[2] = LINE1_3;
    MAT_POSITION[3] = LINE1_4;
    MAT_POSITION[4] = LINE2_1;
    MAT_POSITION[5] = LINE2_2;
    MAT_POSITION[6] = LINE2_3;
    MAT_POSITION[7] = LINE2_4;
    MAT_POSITION[8] = LINE3_1;
    MAT_POSITION[9] = LINE3_2;
    MAT_POSITION[10] = LINE3_3;
    MAT_POSITION[11] = LINE3_4;

    if(direction == FRONT){
        #ifdef TURNING_DELAY_DAIWANG
        if(MAT_POSITION[3]){
            TURN_RIGHT_SUCCESS = TRUE;
        }
        if(MAT_POSITION[2]){
            TURN_LEFT_SUCCESS = TRUE;
        }
        #endif
        #ifdef TURING_DELAY_MY
        if(MAT_POSITION[10]){
            TURN_LEFT_SUCCESS = TRUE;
            TURN_RIGHT_SUCCESS = TRUE;
        }
        #endif
    }else{
        #ifdef TURNING_DELAY_DAIWANG
        if(MAT_POSITION[8]){
            TURN_RIGHT_SUCCESS = TRUE;
        }
        if(MAT_POSITION[7]){
            TURN_LEFT_SUCCESS = TRUE;
        }
        #endif
        #ifdef TURING_DELAY_MY
        if(MAT_POSITION[11]){
            TURN_LEFT_SUCCESS = TRUE;
            TURN_RIGHT_SUCCESS = TRUE;
        }
        #endif
    }
}
/*����ת�������־*/
void setTurningRestart(void){
    TURN_LEFT_SUCCESS = FALSE;
    TURN_RIGHT_SUCCESS = FALSE;
}
